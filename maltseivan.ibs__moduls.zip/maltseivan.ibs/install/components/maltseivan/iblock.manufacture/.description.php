<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
    'NAME' => 'Производители',
    'DESCRIPTION' => 'Компонент вывода детальной страницы',
    'CACHE_PATH' => 'Y',
    'SORT' => 40,
    'COMPLEX' => 'Y',
    'PATH' => array(
        'ID' => 'market.ibs',
        'NAME' => 'Компоненты__m',
    )
);
