<? if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
    'NAME' => 'Комплексный компонент',
    'DESCRIPTION' => 'Универсальный компонент для информационного блока',
    'CACHE_PATH' => 'Y',
    'SORT' => 40,
    'COMPLEX' => 'Y',
    'PATH' => array(
        'ID' => 'market',
        'NAME' => 'maltseivan__ibs',
    )
);