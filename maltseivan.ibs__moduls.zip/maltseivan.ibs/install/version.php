<?php
/**
 * Created by phpStorm
 * User: maltseivan
 * Date: 24.03.2023
 * Time: 22:47
 * version.php
 **/

$arModuleVersion = array(
    "VERSION" => "1.0.0",
    "VERSION_DATE" => "24.03.2023 22:47:00"
);
